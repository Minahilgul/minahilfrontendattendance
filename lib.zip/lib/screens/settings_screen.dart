import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import '../widgets/base_scaffold.dart';
import '../core/services/system_setting_service.dart';
import '../core/theme/app_colors.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final storage = GetStorage(); 
  String token = ""; 

  List<dynamic> settings = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    loadToken(); 
  }

  
  Future<void> loadToken() async {
    String? savedToken = storage.read<String>('token'); //  GetStorage
    print("Secure Token Loaded: $savedToken");

    if (savedToken != null && savedToken.isNotEmpty) {
      setState(() => token = savedToken);
      fetchSettings(); 
    } else {
      setState(() => isLoading = false);
      _showSnack('Login karo pehle');
    }
  }

  Future<void> fetchSettings() async {
    setState(() => isLoading = true);
    try {
      final fetchedSettings = await SystemSettingService.fetchSettings(token);
      setState(() {
        
        settings = fetchedSettings.where((s) => 
          s['key'] != 'parent_verification_mode' && 
          s['key'] != 'parent_verificiation_mode'
        ).toList();
        isLoading = false;
      });
    } catch (e) {
      setState(() => isLoading = false);
      _showSnack('Error: $e');
    }
  }

  Future<void> updateSetting(int id, String value) async {
    final success = await SystemSettingService.updateSetting(
      id: id,
      value: value,
      token: token,
    );
    if (success) {
      fetchSettings();
      _showSnack('Setting updated');
    } else {
      _showSnack('Update failed');
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: AppColors.success)
    );
  }

  @override
  Widget build(BuildContext context) {
    return BaseScaffold(
      title: 'System Settings',
      role: 'admin',
      body: isLoading
      ? Center(child: CircularProgressIndicator(color: AppColors.success))
        : settings.isEmpty
       ? Center(child: Text('No settings found'))
        : ListView.builder(
            padding: EdgeInsets.all(16),
            itemCount: settings.length,
            itemBuilder: (context, index) {
              var setting = settings[index];
              TextEditingController controller =
                TextEditingController(text: setting['value'].toString());

              return Container(
                margin: EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: AppColors.card,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8)],
                ),
                child: ListTile(
                  contentPadding: EdgeInsets.all(16),
                  title: Text(setting['key'], style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                  subtitle: Padding(
                    padding: EdgeInsets.only(top: 4),
                    child: Text(setting['description']?? '', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (setting['type'] == 'boolean')
                        Switch(
                          value: setting['value'].toString() == 'true',
                          activeColor: AppColors.success,
                          onChanged: (val) => updateSetting(setting['id'], val ? 'true' : 'false'),
                        )
                      else ...[
                        SizedBox(
                          width: 100,
                          child: TextField(
                            controller: controller,
                            textAlign: TextAlign.center,
                            keyboardType: setting['type'] == 'number'? TextInputType.number : TextInputType.text,
                            decoration: InputDecoration(
                              isDense: true,
                              contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                          ),
                        ),
                        SizedBox(width: 8),
                        IconButton(
                          icon: Icon(Icons.save, color: AppColors.success),
                          onPressed: () => updateSetting(setting['id'], controller.text),
                        ),
                      ]
                    ],
                  ),
                ),
              );
            },
          ),
    );
  }
}