import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:get_storage/get_storage.dart';
import 'device_service.dart';
import '../config/environment.dart';

class AuthService {
  //  BASE URL - Web ke liye localhost nahi, 127.0.0.1 rakhna ha
  static const String baseUrl = Environment.apiBaseUrl;

  static Map<String, dynamic>? currentUser;
  static String? token;
  static final storage = GetStorage();

  //  login function 
  static Future<Map<String, dynamic>> login(
      String email, String password, {double? latitude, double? longitude}) async {
    try {
      final deviceId = await DeviceService.getDeviceId();
      print(deviceId);
      final response = await http.post(
        Uri.parse('$baseUrl/login'),
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: jsonEncode({
          "email": email,
          "password": password,
          "device_id": deviceId,
          "latitude": latitude,
          "longitude": longitude,
        }),
      );

      print("DEVICE ID: $deviceId");
      print("LOGIN STATUS: ${response.statusCode}");
      print("LOGIN BODY: ${response.body}");

      final contentType = response.headers['content-type'] ?? '';
      if (!contentType.contains('application/json')) {
        return {
          "success": false,
          "message": "Server error (${response.statusCode})"
        };
      }

      final data = jsonDecode(response.body);

      if (response.statusCode == 200 && data['success'] == true) {
        final result = data['result'] ?? {};
        token = result['token'] ?? '';
        currentUser = result;
        await storage.write('token', token);
        await storage.write('user', jsonEncode(currentUser));
        print("Token saved: $token");
        return data;
      } else {
        return {"success": false, "message": data['message'] ?? 'Login failed'};
      }
    } catch (e) {
      print("LOGIN ERROR: $e");
      return {"success": false, "message": "Server error: $e"};
    }
  }

  // register 
  static Future<Map<String, dynamic>> register(
      Map<String, dynamic> body) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/signup'),
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: jsonEncode(body),
      );

      print("REGISTER STATUS: ${response.statusCode}");
      print("REGISTER BODY: ${response.body}");

      final contentType = response.headers['content-type'] ?? '';
      if (!contentType.contains('application/json')) {
        return {
          "success": false,
          "message": "Server error (${response.statusCode})"
        };
      }

      final data = jsonDecode(response.body);

      if (response.statusCode == 200 || response.statusCode == 201) {
        return {"success": true};
      } else {
        return {
          "success": false,
          "message": data['message'] ?? 'Registration failed'
        };
      }
    } catch (e) {
      print("REGISTER ERROR: $e");
      return {"success": false, "message": "Server error: $e"};
    }
  }

  // get token
  static Future<String?> getToken() async {
    if (token == null) {
      token = storage.read<String>('token');
    }
    print("GET TOKEN: $token");
    return token;
  }

  // load token
  static Future<void> loadToken() async {
    token = storage.read<String>('token');
    final String? userJson = storage.read<String>('user');
    if (userJson != null) {
      currentUser = jsonDecode(userJson);
    }
    print("Token Loaded: $token");
    print("User Loaded: $currentUser");
  }

  // logout function
  static Future<void> logout() async {
    token = null;
    currentUser = null;
    await storage.remove('token');
    await storage.remove('user');
  }
}